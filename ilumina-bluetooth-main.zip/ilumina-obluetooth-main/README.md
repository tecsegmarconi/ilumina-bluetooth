# ilumina-obluetooth
Programa para protótipo de automação residencial utilizando Microcontrolador Arduino e módulo bluetooth onde a iluminação é controlada por celular.
Software utilizado no celular: Bluetooth Automation.
